# Handoff: Betongold Tycoon — Konsolidiertes UI-Redesign

## Overview
Konsolidierter Design-Vorschlag für die gesamte Spiel-UI von **Betongold Tycoon**.
Er führt die drei bisherigen Proposals (A „Cozy Brettspiel", B „Anno Stadtpanorama",
C „Moderner Game-HUD") nach dem Feedback zu **einem** Zielbild zusammen und deckt alle
Screens und Overlays ab. Grundgerüst = Proposal B (Petrol/Gold, gläsernes HUD über der
lebendigen Stadt), plus die vom Nutzer bevorzugten Elemente aus A und C.

## About the Design Files
Die Datei in diesem Bundle (`Konsolidiertes Redesign.dc.html`) ist eine **Design-Referenz
in HTML** — ein Prototyp, der Aussehen und Verhalten zeigt, **kein** produktiv zu
kopierender Code. Aufgabe ist, dieses Design in der **bestehenden Codebasis**
(`js/ui/*.js`, Vanilla-JS-Screens) mit deren etablierten Mustern nachzubauen — nicht das
HTML direkt auszuliefern. Die DC-spezifische Mechanik (`{{ }}`-Holes, `<sc-for>`, `<sc-if>`,
`DCLogic`, `support.js`) ist reines Prototyping-Gerüst und wird **nicht** übernommen; relevant
sind Layout, Maße, Farben, Typo, Copy und Verhalten.

## Fidelity
**High-fidelity.** Finale Farben, Typografie, Abstände, Icons und Interaktionen sind
verbindlich gemeint. Pixelnah nachbauen; wo die bestehende Codebasis eigene Bausteine hat,
diese verwenden, aber auf die hier dokumentierten Werte bringen.

---

## Design Tokens

### Farben
| Rolle | Hex |
|---|---|
| Bühnen-/App-Hintergrund | `#141b22` |
| Panel-Verlauf oben | `rgba(30,38,48,0.95)` |
| Panel-Verlauf unten | `rgba(19,25,33,0.96)` |
| Panel-Rand (Gold, dezent) | `rgba(238,205,133,0.26–0.35)` |
| Gold hell (Überschriften, Werte) | `#f4dd9b` |
| Gold (Akzent/Icons) | `#eecd85` / `#e6c264` / `#d9b464` |
| Gold-Verlauf Primärbutton | `linear-gradient(180deg,#eecd85,#c69a3f)`, Button-Text `#241d10`, Schlagschatten `0 3px 0 #8a6a24` |
| Text hell | `#efe7d5` |
| Text sekundär | `#c8bd9f` |
| Text tertiär/Labels | `#a89c7f` |
| Text schwach/Meta | `#8b8069` |
| Positiv (Grün) | `#9ed19e` (Fläche `rgba(143,188,143,0.08–0.18)`) |
| Negativ (Terrakotta) | `#e0a084` (Fläche `rgba(224,160,132,0.14–0.16)`) |
| Info (Blau) | `#7ea8d8` / `#a9c9ee` |
| Bau/Sonder (Lila) | `#b79bd6` / `#cdb8e4` |
| Bestand (Grün-Marker) | `#6fae7f` |

Stadt-spezifische Hintergrund-Tönung (Wash-Overlay über dem Bühnenbild):
- Berlin Innen: `linear-gradient(180deg, rgba(34,60,74,0.52), rgba(18,30,40,0.3) 55%, rgba(12,20,28,0.55))`
- Berlin Außen: `…rgba(44,64,52,0.52), rgba(22,36,28,0.3) 55%, rgba(14,24,18,0.55)`
- Leipzig: `…rgba(80,60,34,0.52), rgba(44,32,20,0.3) 55%, rgba(28,20,12,0.55)`
- Meißen: `…rgba(78,52,60,0.5), rgba(42,28,34,0.3) 55%, rgba(24,18,22,0.55)`

### Typografie
- **Display/Überschriften:** `'Cormorant Garamond', serif`, 600/700. Screen-Titel 22px, Panel-Titel 17–19px, Großzahlen (Gebot/Endbilanz) 27–40px.
- **UI/Fließtext:** `'Alegreya Sans', system-ui, sans-serif`, 400/500/700/800. Basis 15px, Meta 10–12px, Labels 10px uppercase `letter-spacing:0.06–0.1em`.
- Zahlen immer `font-variant-numeric: tabular-nums`.

### Radius / Abstände / Schatten
- Radius: Panels 16px, Karten/Boxen 11–14px, Pills/Chips 8–10px, Kreise 50%.
- Panel-Padding 13–20px; Grid/Flex-`gap` 8–16px.
- Panel-Schatten `0 12–16px 32–48px rgba(0,0,0,0.45–0.55)`; `backdrop-filter: blur(6–10px)`.

### Icons
Kohärentes **Linien-Icon-Set (Lucide-Stil)**: `viewBox 0 0 24 24`, `fill:none`,
`stroke:currentColor`, `stroke-width:2`, runde Enden. Farbe = jeweilige Textfarbe der
Umgebung (Gold/Creme), auf farbigen Tokens weiß. **Keine Emoji.** Verwendete Icons u.a.:
coins, trending-up/down, line-chart, scroll-text, map, landmark, scale, building-2, wallet,
heart, clock, zap, shield, mail, wrench, ruler, door-open, hammer, search, layers, piggy-bank,
brush, bath, flask-conical, hourglass, home, sparkles, flag, rotate-ccw, settings, save, help,
compare, pen, briefcase, tag, pause.
**Semantik-Regeln (wichtig, aus Feedback):** Cashflow = `trending-up` (kein Tropfen);
Liquiditätspuffer = `shield`; Marktplatz = `scale`; Zimmer = `door-open`; Fläche = `ruler`.
**Kein Humor/keine verspielten Symbole in Navigation & Chrome** — Witz nur situativ in
Inhalten (Makler-Zitate, Ereignisse).

---

## Persistente Struktur (Shell)

### Stadt als dauerhafte Bühne
- Vollflächiges Hintergrundbild `assets/ui/city-backdrop.webp`, **bewusst atmosphärisch**:
  `filter: saturate(0.7) brightness(0.64) blur(3px); transform: scale(1.06)`, darüber die
  Stadt-Wash (s.o.) + vertikaler Abdunkel-Verlauf. **Konzept-Entscheidung:** Hintergrund ist
  reine Stimmung (keine lesbaren Einzelgebäude → kann Exposés nie widersprechen); die einzigen
  scharfen Gebäude auf der Karte sind **echte Exposé-Kacheln**. Pro Stadt nur Tönung/Blur
  variieren, keine faktisch riskante gemalte/generierte Karte.

### Obere HUD-Leiste (`z-index:30`, top:0, transparent, space-between)
- **Links:** Logo (kleines gestapeltes Balken-SVG in Gold + Wortmarke „Betongold Tycoon" in
  Cormorant 22px `#f4dd9b`) · Trennstrich · 3 Ressourcen-Pills (Tagesgeld `coins`/gold,
  Cashflow/M. `trending-up`/grün, ETF-Depot `line-chart`/creme). Jede Pill: Glas-Verlauf,
  Gold-Rand, Icon links + Label(10px uppercase)/Wert(14.5px) gestapelt, klickbar → Finanzen bzw.
  Haushalt.
- **Rechts:** Geschwindigkeitsanzeige (Pause + Tempo 0,5/1/3 mit Play-Dreieck; aktuell Pause
  gold aktiv), Datumsblock „März 2029 / Jahr 4/27 · Alter 43", `+1 Monat` / `+1 Jahr`,
  Hilfe-Button (`help`), Menü-Button (`menu`) mit Dropdown.
- **Menü-Dropdown:** Spielhilfe, Einstellungen, Spielstände, Neues Spiel, Endbilanz (Vorschau),
  Neustart — jeweils Linien-Icon + Label.

### Untere Navigation (`z-index:20`, bottom, links)
5 Tabs, aktiver Tab = Gold-Verlauf + dunkler Text/Icon, inaktiv = Glas-Pill:
**Stadt** (`map`) · **Zentrale** (`landmark`) · **Marktplatz** (`scale`) · **Objekte**
(`building-2`) · **Finanzen** (`wallet`). Icon 20px oben, Label 12.5px/800 darunter.

---

## Screens / Views

### 1. Stadt (Home)
**Zweck:** Überblick, Navigation in Orte, Städtewechsel.
- **Stadtumschalter** (oben mittig, `z-index:25`, top:84px): 4 Segmentbuttons
  **Berlin·Innenstadt / Berlin·Außenstadt / Leipzig / Meißen+Umland**; aktiv = Gold-Rand +
  `rgba(238,205,133,0.16)`. Wechsel tauscht Hintergrund-Wash **und** die Marker-/Orte-Menge.
- **Karten-Marker** (`z-index:6`): pro Ort eine Kachel (Breite 154px) = echtes Exposé-Bild
  (`assets/expose/*.webp`, 80px hoch) + Status-Icon-Badge oben links (Farbe = Statusfarbe,
  Icon dunkel `#10161d`) + Titel/Sub; darunter Stiel + Punkt in Statusfarbe. Pausierte Objekte:
  Bild `grayscale(0.62) brightness(0.72)`. Klick → Exposé/Marktplatz/Objekt. Status→Farbe/Icon:
  zu verkaufen `tag`/`#e6c264`, Gebot abgegeben `hourglass`/`#7ea8d8`, Baustelle `hammer`/`#b79bd6`,
  Bestand/vermietet `home`/`#6fae7f`, pausiert `pause`/`#8d979e`.
- **Links Familie-Panel** (322px): Avatar `assets/avatar/t-05.webp` + „Familie Weber — Euer
  wichtigstes Asset, nicht beleihbar." Darunter **Sims-Balken** (aus Proposal A): Familie
  (`heart`/78), Zeit (`clock`/14h), Nerven (`zap`/82), Puffer (`shield`/6,9 M.) — Token-Kreis
  farbig mit weißem Icon, Balken mit Verlauf, Wert rechts. Hinweis: Presets verschieben diese
  Startwerte.
- **Links Post-Panel** (aus A der Begriff „Post", aus B das kompaktere Design): Liste
  klickbarer Einträge, Icon (`mail`/`wrench`/`landmark`/`scale`) + „Absender: Text".
- **Rechts Orte-Panel:** Liste der Orte der aktuellen Stadt (Statuspunkt + Titel/Sub, klickbar).
- **Rechts „Nächster kluger Zug":** Gold-getönte Hinweiskarte mit CTA („Objekt ansehen →").

### 2. Zentrale (Kontor)
Vollflächiges Panel (left/right 20px, top 84px, bottom 88px). Header „Zentrale — eure Bücher"
+ 3 Tabs (Unterstrich-Stil): **Vermögen** (`trending-up`) / **Haushalt** (`scale`) / **Objekte**
(`building-2`).
- **Vermögen:** 3 KPI-Boxen (Nettovermögen 412.300 €, ETF-Benchmark 389.100 €, LTV 51 %).
  **„Das große Kontobuch"** (aus A): SVG-Liniendiagramm, goldene Kurve „Euer Vermögen" mit
  Flächenverlauf `#kbF` vs. gestrichelte blaue „ETF-Schattenflotte", **Meilenstein-Marker**
  (Plagwitz/Pankow gekauft) mit Punkt+Label, Achsenbeschriftung 2026–2028. Darunter
  **Vermögensmix** (gestapelte Balkenleiste + Legende) und **Liquiditätspuffer** (`shield`,
  Balken 92% = 6,9 Monate, Empfehlung nie <3).
- **Haushalt:** 3 Spalten — Familie/Sims-Balken · **Haushaltskasse März 2029** (Einnahmen grün,
  Alltag/Sparen terrakotta, Summe „auf Tagesgeld +1.050 €", Auto ab Monat 5 vorgemerkt) ·
  **Finanzamt** (35 % Grenzsatz, Rückstellung `piggy-bank`).
- **Objekte:** Kartenraster der eigenen Objekte (Bild links 118px, Titel + Status-Pill,
  Cashflow farbig, EK-Quote-Balken „euch/Bank") + gestrichelte „+ Neue Objekte"-Karte.
  (Der eigene Objekte-Tab stammt aus A — bewusst behalten.)

### 3. Marktplatz
Panel wie Zentrale. Header „Der Marktplatz" + Filterzeile (Segment / Vermietung / Sortierung /
nur ★ / **Vergleichen** `compare`).
- **Vertikal gestapelte Zeilen** (aus C): je Angebot eine `article`-Zeile, Grid
  `196px 196px 1fr 216px`:
  1. **Außenansicht** (`assets/expose/*.webp`) mit Tag-Badge oben links + Label „Außen"
  2. **Innenansicht** (`assets/cutaway/*_saniert|unsaniert.webp`) + Label „Innen"
     — beide Ansichten sind Pflicht (Feedback).
  3. Titel/Ort, Meta mit Icons (`ruler` Fläche, `door-open` Zimmer, `hammer` Baujahr, `zap`
     Energieklasse), Zustands-Chips, Makler-Zitat (situativer Humor erlaubt).
  4. Preis groß (Cormorant), Rendite; Buttons **Prüfen** (`search`) + **Gebot abgeben** (gold).
- Bilder dürfen größer sein als im alten Stand; Layout näher an A, Skin/Optik an B.

### 4. Objekte / Objekt-Detail (Baustelle Pankow)
Panel; Header mit Zurück, Titel, Status-Pill, **Innen/Außen-Umschalter**.
- Links: großes Bild (Innen = `assets/cutaway/br-01_saniert.webp`, Außen =
  `assets/expose/br-01.webp`), Hinweis „zum Zoomen klicken". Darunter **Gewerke** (aus A/B):
  Zeilen Bad `bath` / Elektrik `zap` / Maler `brush`, je Fortschrittsbalken + %.
- Rechts: **Zahlen als sortierte Zeilen mit farbig hinterlegtem Wert** (Feedback: **keine**
  großen KPI-Cards): Wert heute (gold) · Restschuld (Bank, terrakotta) · Cashflow jetzt
  (terrakotta) · Cashflow nach Vermietung (grün). Container `rgba(0,0,0,0.18)`, Zeilen mit
  dünnem Divider, Wert-Chip mit farbigem Hintergrund.
  Darunter **„Wer zieht ein?"** (aus A) mit Bewerber-Vorschau → Button „Bewerbermappe öffnen".
  Aktionen: Renovieren `hammer` / Verkaufen `coins`.

### 5. Finanzen
Panel. Header „Finanzen — Konten & Depot".
- **4 Konten-Karten** (linker Farbstreifen = Akzent): Tagesgeld `coins`/`#6fae7f`,
  Immobilienportfolio `building-2`/`#7ea8d8`, Welt-ETF `line-chart`/`#c69a3f`,
  Einzelaktien-Sandbox `flask-conical`/`#9b7fb8` (Badge „Lernumgebung · keine Empfehlung").
- **Umschichten (interaktiv, dynamisch):** ein **Slider** (−20.000…+20.000 €, Schritt 500,
  Mitte = halten). Zwei Konto-Kacheln (Tagesgeld / Welt-ETF) zeigen **live** den Nachher-Wert
  + farbiges Delta; Mittelpfeil `→ / ← / —`. Kontextzeile rechnet live: bei Anlegen
  Renditehinweis, bei Verkauf **Steuer-Vorschau (~2,87 %) + Netto**. Primärbutton-Label und
  -Farbe richten sich nach Betrag/Richtung (bei 0 „Betrag am Slider wählen", inaktiv).
  Darunter **ETF-Sparplan**-Slider (Anteil der Sparrate, 50 % · 1.305 €/M.).
- **Vermögensmix** (Balkenleiste + Legende), **Einzelaktien-Sandbox** (Zeilen mit Risiko/
  Dividende/Position/G+V), **Letzte Bewegungen** (Icon + Text + Betrag farbig).

---

## Overlays / Modals

### Exposé (zentriert, ~1000px)
Header Titel + Eckdaten. Links **Außen- über Innenansicht** (2 Reihen). Rechts Preis groß,
Rendite, **Gutachter-Block** (Bausubstanz/Miete vs. Markt/Dach/Lage mit ✓/⚠), Zitat,
CTA „Zur Finanzierung →".

### Finanzierung (rechtes Seitenpanel, ~560px) — 3-Schritt-Flow (Konzept aus A, Skin aus B)
Header Bank-Avatar `assets/avatar/t-01.webp` „Bankhaus Krause & Töchter". Tabs mit fester
Reihenfolge **1. Nutzung → 2. Eigenkapital → 3. Rate & Urteil**:
1. **Nutzung:** Kapitalanlage (`briefcase`, gewählt) vs. Eigenheim (`home`, gesperrt mit
   Begründung).
2. **Eigenkapital:** EK-%-Schnellwahl + zwei Slider (Eigenkapital €, Tilgung %), Hinweis auf
   ETF-Umschichtung.
3. **Rate & Urteil:** Aufstellung (Kaufpreis, Nebenkosten „sofort weg", Darlehen, Rate),
   **LTV-Ampelbalken** mit Marker bei 80 %, „Wirkung auf euren Monat" (+1.050 → −560),
   Banker-Fazit (`pen`).
Footer Zurück/Weiter, in Schritt 3 „Kauf besiegeln" (grün).

### Gebot abgeben (zentriert, ~560px) — mit Slider (neu, Feedback)
Header Objekt-Thumb + Titel/Ort. Angebotspreis; **großes live-Gebot** (Cormorant 40px) +
Delta-Zeile. **Slider −12 %…+12 %** vom Angebot (Schritt 1 %). **Annahme-Chance**: Label +
farbiger Balken + Note ändern sich live (unwahrscheinlich `#e0a084` / denkbar `#eecd85` /
wahrscheinlich · so gut wie sicher `#9ed19e`). Konkurrenz-/Bindungszeile. Primär
„Gebot abgeben → Finanzierung" (führt in den Finanzierungs-Flow).

### Bewerbermappe (zentriert, ~640px)
Avatar `assets/avatar/t-02.webp` „Dr. Lena Hoffmann". Links **sichtbare Fakten**
(Beruf, Haushalt, Einkommen, Bonität, Vormieter, Mietwunsch). Rechts „Was folgt aus den
Fakten", Notiz, Leerstand-Warnung. Footer Weitersuchen / Zusage senden.

### Ereignis (zentriert, ~620px)
Kategorie-Icon (`wrench`) + Titel „Die Heizung in Pankow gibt auf", Beschreibung, **3 Optionen**
als Auswahlkarten (Titel + farbige Folge + Detail): Notdienst / 3 Angebote / vertrösten.

### Einstellungen (rechtes Seitenpanel, ~600px) — **umbenannt von „Werkstatt"**
Tabs **Wirtschaft** (`wallet`) / **Spielgefühl** (`heart`) / **Regeln** (`scroll-text`).
Pro Feld: Label + Wert + Slider + Hilfetext. Footer „Auf Standard" / „Übernehmen".
Hinweis: „Regler wirken ab dem Folgemonat". (Darf größer sein als der alte Stand.)

### Neues Spiel (zentriert, ~940px)
**Presets** (Startlage) als Bildkarten mit „STANDARD"-Badge: Familienstrategie mit Puffer /
Klassischer 30-Jahre-Einstieg / Fünf-Objekte-Stresstest / Handwerker-Azubi (17). **Schwierigkeit**
Leicht/Normal/Schwer (unabhängig von Startlage). `<details>` „Startwerte anpassen" mit zwei
Spalten: **nur beim Start** vs. **auch später änderbar** (17 Felder). Live-Vorschau-Zeile.

### Endbilanz (zentriert, ~720px) — „Private Endbilanz, kein öffentlicher Highscore"
4 KPIs (Endvermögen, ggü. ETF, Objekte, Lebensende) + **Lebensweg-Timeline** (Alter + Ereignis).

### Spielhilfe (zentriert, ~820px)
Schritt-Chips (nummerierte Tour) + 6 Kapitelkarten (Ziel & Zeit, Marktplatz & Prüfung,
Finanzierung, Vermietung & Mieter, Steuern & Fristen, Finanzen & ETF). CTA „Bildschirm-Tour".

---

## Interactions & Behavior
- **Navigation:** untere Tabs setzen den Screen; HUD-Ressourcen und „Nächster Zug" sind
  Shortcuts (Finanzen, Haushalt, Objekt). Menü-Button öffnet Dropdown.
- **Stadtwechsel:** Segmentwahl setzt aktive Stadt → Hintergrund-Wash + Marker/Orte wechseln.
- **Overlays:** Klick auf dunklen Backdrop schließt; Klick im Panel `stopPropagation`; „✕" schließt.
- **Gebot-Slider:** `onChange` → State `gebotPct`; Gebotspreis (auf 100 € gerundet), Delta,
  Annahme-Chance/Farbe/Note live.
- **Umschichten-Slider:** `onChange` → State `umschicht` (€); Nachher-Werte, Deltas, Steuer/Netto,
  Buttontext/-farbe live.
- **Finanzierung:** Weiter/Zurück begrenzt auf Schritt 1–3; Schritt 3 zeigt „Kauf besiegeln".
- **Innen/Außen-Umschalter** im Objekt-Detail wechselt Bildquelle.
- Hover: Buttons/Karten heben Rand-/Hintergrundgold leicht an.

## State Management
Zentrale UI-States (im Prototyp `DCLogic`; im Repo äquivalent):
`screen` (stadt|zentrale|markt|objekt|finanzen), `zTab` (vermoegen|haushalt|objekte),
`stadt` (berlin-innen|berlin-aussen|leipzig|meissen), `overlay`
(null|expose|finanzierung|gebot|bewerber|event|einstellungen|neuesspiel|endbilanz|hilfe),
`bankStep` (1–3), `einTab` (wirtschaft|gefuehl|regeln), `ansicht` (innen|aussen),
`menu` (bool), `exposeId`, `gebotId`, `gebotPct` (88–112), `umschicht` (−20000…20000).
Abgeleitet berechnet: Gebotspreis/Annahme, Umschicht-Nachher/Steuer, Marker-/Orte-Menge je Stadt.

## Assets (bestehende Repo-Assets, unverändert genutzt)
- Bühne: `assets/ui/city-backdrop.webp`
- Exposé (Außen): `assets/expose/{bi-01..05, br-01..03, le-01..04, ro-01..02}.webp`
- Cutaway (Innen): `assets/cutaway/{bi-01_saniert, bi-01_unsaniert, bi-02_unsaniert, bi-03_saniert, br-01_saniert, le-02_saniert, ro-01_saniert}.webp`
- Avatare: `assets/avatar/{t-01, t-02, t-03, t-05}.webp`
- Icons: **kein** Asset — inline SVG (Lucide-Stil), Werte s. „Icons". Logo = einfaches Balken-SVG.
- Favicon/Browser-Icon (Feedback, noch offen): kleines Betongold-Mark ableiten (z. B. das
  gestapelte Balken-Logo) und als App-/Tab-Icon setzen.

## Städte / Daten (Prototyp-Beispieldaten — im Repo durch echte Spielzustände ersetzen)
Vier Städte mit je 3–4 Orten (Berlin Innen/Außen, Leipzig, Meißen). Beträge, Bewohner, Status
sind Platzhalter zur Illustration des Layouts.

## Files
- `Konsolidiertes Redesign.dc.html` — vollständiger interaktiver Prototyp (alle Screens/Overlays).
- Ziel-Codebasis: `js/ui/*.js` (dashboard, markt, objekt/bewerber, finanzen, admin/Einstellungen,
  endgame, …) auf diesen Stand bringen; `DESIGN_SYSTEM.md` / `STYLE_GUIDE.md` mit den Tokens oben
  abgleichen.

## Offene inhaltliche Punkte (vom Nutzer markiert)
- „Liquiditätsspeicher"/Puffer-Begriff inhaltlich prüfen.
- Favicon/Spiel-Symbol ergänzen.
- Marktplatz braucht in der echten Version mehr Detailtiefe (mehr Raum einplanen).
